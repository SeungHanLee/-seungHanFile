<카카오뱅크 코딩과제 : 학교이름 찾기와 카운트 하기>
1. Framework : Spring boot
2. DB : H2 Memory DB, MyBatis
3. Language : JAVA, JSP, BootStrap

4. 코드 구성
4.1 Controller 
    4.1.1 SchoolController
        - URL : /
          .method : get방식
          .input : null
          .output: String value
        - URL : /getResult
          .method : get 방식
          .input : null
          .output : String value
4.2 Service 
    4.2.1 CoreService
        - 기능 : main 기능을 하는 서비스. csv파일을 읽어오고, 중/고등학교 키워드를 찾는 서비스를 호출
        - method : void run() 
    4.2.2 Leng2MidName
        - 기능 : 학교이름이 두 자리인 중학교, 여자중학교를 찾고 DB에 insert 
        - method : findNinsertLeng2Name(String str, List<Integer> list) 
    4.2.3 NormalHighName
        - 기능 : 대부분의 고등학교( 남고, 여고, 인문계, 실업계, 특수 고)이름을 찾고 DB 에 insert
        - method : findNinsertNormalHighName(String str, List<Integer> list)
    4.2.4 ReadCsvService
        -기능 : csv파일을 읽어옴
        -method : ArrayList<String> getCsvContents()
    4.2.5 SchoolNameInsertService
        -기능 : 찾은 학교이름을 DB 에 insert 함
        -method : public void setSchoolName(String sName)
    4.2.6 StringFindService
        -기능 : 읽어온 csv파일에서 찾고자하는 스트링의 인덱스값을 찾음. KMP알고리즘을 이용하여 일반 스트링비교 O(NM)복잡도가 아닌
                O(N+M) 복잡도의 빠른속도로 스트링비교가 가능
        -method :  public List<Integer> search(String string, String pattern) , public int[] getPI(String pattern)
    4.2.7 OmittedMidName
        -기능 : ~~중 , ~~여중 처럼 학교가 생략된 중학교이름을 찾음
        -method : public void findNinsertOmittedMidName(String str, List<Integer> list) 
4.3 Mapper
    4.3.1 SchoolMapper
        -기능 : DB에 찾은 학교이름을 DB에 insert , DB 에  insert된 학교이름 리스트를 가져옴
        -method : public void setSchoolName(String sName), public List<SchoolVO> getSchoolRank() throws Exception;
4.4 VO
    4.4.1 SchoolVO
        -기능 : 학교명과 학교 카운트 수 셋, 겟 함.
        -method : public String getName() , public void setName(String name), public int getNameRank(), public void setNameRank(int nameRank) 

5. DB Schema
    5.1 기능
        - 찾아낸 중/고등학교의 갯수를 알아볼수 있게 DB 에 insert 하여 group by로 정렬
    5.2 쿼리
        -CREATE TABLE SCHOOL_NAMES
        (SCHOOL_NAME VARCHAR(20));

6. 실행방법
    6.1 서비스 기동
        - project -> run as -> spring boot app 실행 (스트링 부트 프로젝트 이기때문에 톰캣 내장되어 실행)
    6.2 웹브라우저 접속 (restful API)
        - localhost:8080/ 
    6.3 서비스 사용 (restful API)
        - 결과보기 버튼 클릭 (localhost:8080/getReust)
    cf1 )스프링 부트 프로젝트 이기 때문에 jar 로 build 하여 원하는 서버에 저장후 jar만 실행시켜도 서비스 기동 가능
    

    
